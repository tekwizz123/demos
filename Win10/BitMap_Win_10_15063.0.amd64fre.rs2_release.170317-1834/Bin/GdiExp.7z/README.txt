this ver will work one out of 20 it the good case,
the ulClientDelta is not calculated very good,
and as such it will likely BSOD,
try to run only if the pointers are close (4 fig diff).